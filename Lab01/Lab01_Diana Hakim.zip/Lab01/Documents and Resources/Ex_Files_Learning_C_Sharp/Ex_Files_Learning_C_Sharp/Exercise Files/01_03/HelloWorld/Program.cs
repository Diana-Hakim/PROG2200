﻿using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            var anything = "My String";
            Console.WriteLine(anything);
        }
    }
}
