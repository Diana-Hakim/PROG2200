Survey is a program with input error checking.
Survey02 is a program without input error checking.
