Survey is a simple implementation of the program using the video courses code
Zodiac is using my previous assignmnet answer for the question.  