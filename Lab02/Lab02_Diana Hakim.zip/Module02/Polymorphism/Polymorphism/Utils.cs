﻿using System;
using System.Collections.Generic;

//
//
//

namespace Polymorphism
{
    public class Utils {
        public virtual List<IWorker> GetMockWorkers()
        {
            throw new NotImplementedException();
        }

    }
}
